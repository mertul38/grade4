These images are created by disabling backface culling
in our implementation. The results are very similar to
the backface culling results with some tiny differences.
The images with tiny differences are:

Car.ppm
Car_front.ppm
berserker.ppm
dragon_lowres.ppm
horse_and_mug.ppm
killeroo.ppm
low_poly_scene.ppm
monkey.ppm

The other images are binary equivalent. It is optional
to perform backface culling in your own implementation.
